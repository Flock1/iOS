//
//  HomeVC.m
//  Flock
//
//  Created by Gaurav on 19/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "HomeVC.h"
#import "ApiOperation.h"
#import "Constants.h"
#import "DropDownCell.h"
#import "TravelRouteVC.h"
#import <GoogleMaps/GoogleMaps.h>

@interface HomeVC ()<UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate>

{
    NSArray *arrGeometry;
    NSMutableArray *arrPlaceName;
    NSMutableArray *arrPhotoUrl;
    
    //CLLocationManager *locationManager;
    NSString *currentLatitude;
    NSString *currentLongitude;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    
     ApiOperation *apiOperation;
    
}

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (strong, nonatomic) IBOutlet UITextField *tfSource;
@property (strong, nonatomic) IBOutlet UITextField *tfDestination;

@property (strong, nonatomic) IBOutlet UIButton *btnShowRoute;

@property (strong, nonatomic) IBOutlet UIView      *dropDownView;
@property (strong, nonatomic) IBOutlet  UITableView *tblDropDown;

@property (strong, nonatomic) NSArray *arrSource;
@property (strong, nonatomic) NSArray *arrDestination;

@property (strong, nonatomic) NSArray *arrSourceReference;
@property (strong, nonatomic) NSArray *arrDestinationReference;

@property (strong, nonatomic) NSString *strSelectedSourceReference;
@property (strong, nonatomic) NSString *strSelectedDestinReference;

@property (strong, nonatomic) NSMutableArray *sourceLatLong;
@property (strong, nonatomic) NSMutableArray *destinationLatLong;

@property (strong, nonatomic) NSArray *arrSubwayResults;



@property (nonatomic)  BOOL isSourceTable;

@property (nonatomic, weak) IBOutlet NSLayoutConstraint *topConstraintDropDownView;

- (IBAction)btnDestination_Action:(id)sender;
- (IBAction)btnSource_Action:(id)sender;

@end

@implementation HomeVC

#pragma mark - View LifeCycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.arrSource               = [NSArray new];
    self.arrDestination          = [NSArray new];
    self.arrSubwayResults        =  [NSArray new];
    
    self.arrSourceReference      = [NSArray new];
    self.arrDestinationReference = [NSArray  new];
    
    self.sourceLatLong           = [NSMutableArray new];
    self.destinationLatLong      = [NSMutableArray new];
    
    self.tfSource.userInteractionEnabled      = YES;
    self.tfDestination.userInteractionEnabled = YES;
    self.btnShowRoute.userInteractionEnabled  = NO;

    
    self.dropDownView.hidden = YES;
    
    self.dropDownView.layer.borderWidth   = 2.0f;
    self.dropDownView.layer.borderColor   = [UIColor grayColor].CGColor;
    
    self.dropDownView.layer.masksToBounds = YES;
    
    [self CurrentLocationIdentifier];
    
    //For Testing only
    /*
    CLLocationCoordinate2D currentLoc = CLLocationCoordinate2DMake(22.719568,75.857727 );
    //[self.mapView setus]
    [self.mapView setCenterCoordinate:currentLoc];
     */
    
    }


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"TravelRouteVC"]) {
       
        TravelRouteVC *routeVC            = [segue destinationViewController];
        
        routeVC.arrDestinationCoordinates = self.destinationLatLong;
        routeVC.arrSourceCoordinates      = self.sourceLatLong;
    }
}

#pragma mark - Location Methods
//------------ Current Location Address-----
-(void)CurrentLocationIdentifier
{
    locationManager = [CLLocationManager new];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [locationManager requestWhenInUseAuthorization];
        [locationManager requestAlwaysAuthorization];
    }
    //---- For getting current gps location
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
    //------
    
    self.mapView.showsUserLocation = YES;
    
    /*
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorized ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
     
    }*/
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    currentLocation = [locations lastObject];
    [locationManager stopUpdatingLocation];
    
    if (currentLocation != nil) {
        
        currentLongitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        currentLatitude  = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        
        self.tfSource.text = [NSString stringWithFormat:@"My Location. Click to change"];
        self.btnShowRoute.hidden = YES;
        //[self callGoogleAutoCompleteService];
    }
}

#pragma mark - Action Methods
- (IBAction)btnSource_Action:(id)sender
{
    self.arrSource = nil;
    self.arrSourceReference = nil;
    [self.tblDropDown reloadData];

    
    if ([self.tfDestination isFirstResponder]) {
        [self.tfDestination resignFirstResponder];
    }
    
    self.isSourceTable = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        self.dropDownView.hidden = NO;
        self.topConstraintDropDownView.constant = 132.0f;
        [self.view layoutSubviews];
    });
    
    self.btnShowRoute.hidden = YES;

    [self.tfSource becomeFirstResponder];
}

- (IBAction)btnDestination_Action:(id)sender;
{
    self.arrDestination = nil;
    self.arrDestinationReference = nil;
    
    if ([self.tfSource isFirstResponder]) {
        [self.tfSource resignFirstResponder];
    }
    
    self.isSourceTable = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tblDropDown reloadData];
        self.dropDownView.hidden = NO;
        self.topConstraintDropDownView.constant = 178.0f;
        [self.view layoutSubviews];

    });
    
    [self.tfDestination becomeFirstResponder];
    
    
}

#pragma mark - Tableview Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isSourceTable) {
        return self.arrSource.count;
    }else
        {
            return self.arrDestination.count;
        }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //static NSString *cellIdentifier = @"cell";
    
    DropDownCell *cell = [self.tblDropDown dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    if (self.isSourceTable) {
        cell.textLabel.text = self.arrSource[indexPath.row];
    }else
        {
            cell.textLabel.text = self.arrDestination[indexPath.row];
        }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isSourceTable) {
        self.tfSource.text = self.arrSource[indexPath.row];
        
        self.strSelectedSourceReference = self.arrSourceReference[indexPath.row];
        [self  callGetLatLongfromReference:self.strSelectedSourceReference];

    }
    else
        {
            self.tfDestination.text = self.arrDestination[indexPath.row];
            self.strSelectedDestinReference = self.arrDestinationReference[indexPath.row];
            
            [self  callGetLatLongfromReference:self.strSelectedDestinReference];
            self.btnShowRoute.userInteractionEnabled  = YES;

            
            //[self callGetNearBySubwayStations];
        }
    
    [self.dropDownView  setHidden:YES];
}

#pragma mark - TextField Delegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([self.tfSource.text isEqualToString:@"My Location. Click to change"])
 {
    self.tfDestination.text = self.tfSource.text = @"";
 }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self.dropDownView setHidden:YES];
    self.btnShowRoute.hidden = NO;

    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string) {
        [self callGoogleAutoCompleteService:string];
    }
    return YES;
}

#pragma mark - MKMapView delegates

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
    
    static NSString* AnnotationIdentifier = @"Annotation";
    MKPinAnnotationView *pinView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotationIdentifier];
    
    if (!pinView) {
        
        MKPinAnnotationView *customPinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotationIdentifier];
        if (annotation == mapView.userLocation){
            
            NSLog(@"Coordinate %f,=== %f", mapView.userLocation.coordinate.latitude, mapView.userLocation.coordinate.longitude);
            customPinView.image = [UIImage imageNamed:@"marker40"];
        }
        else{
            customPinView.image = [UIImage imageNamed:@"marker20"];
        }
        customPinView.animatesDrop = NO;
        customPinView.canShowCallout = YES;
        return customPinView;
        
    } else {
        
        pinView.annotation = annotation;
    }
    
    return pinView;
}

#pragma mark - service Methods

- (void)callGoogleAutoCompleteService:(NSString *)searchText
{
    NSString *types     = [NSString new];
    //types = @"establishment|subway_station";
    
    types = @"establishment";

    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&location=40.719578,-73.877027&radius=5000&components=country:us&key=%@", searchText, kGOOGLE_API_KEY];
    
    //NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/json?input=%@&location=%@,%@&radius=5000&sensor=false&types=%@&key=%@", searchText, currentLatitude, currentLongitude, types, kGOOGLE_API_KEY];
    
    if ((currentLatitude.length > 0) && (currentLongitude.length > 0)) {
        
    [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
        NSLog(@"Response %@", responseObject);
        
        // Update view
        dispatch_async(dispatch_get_main_queue(), ^{
            if (self.isSourceTable) {
                self.arrSource = [[responseObject objectForKey:@"predictions"] valueForKey:@"description"];
                
                self.arrSourceReference = [[responseObject objectForKey:@"predictions"] valueForKey:@"reference"];
            }else
            {
                self.arrDestination = [[responseObject objectForKey:@"predictions"] valueForKey:@"description"];
                self.arrDestinationReference = [[responseObject objectForKey:@"predictions"] valueForKey:@"reference"];

            }
            self.dropDownView.hidden = NO;
            
            [self.tblDropDown reloadData];
        });
        
    }];
    }
}

- (void)callGetLatLongfromReference:(NSString *)reference
{
    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/details/json?reference=%@&sensor=false&key=%@", reference, kGOOGLE_API_KEY];
    
        [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
            NSLog(@"Response %@", responseObject);
            
            NSString *strLat = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
            
            if (self.isSourceTable) {
                [self.sourceLatLong removeAllObjects];
                
                [self.sourceLatLong addObject:strLat];
                
                NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
                [self.sourceLatLong addObject:strLng];
                
            }else
                {
                    [self.destinationLatLong removeAllObjects];
                    
                    [self.destinationLatLong addObject:strLat];
                    
                    NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
                    [self.destinationLatLong addObject:strLng];
                }
            
            if (self.sourceLatLong.count > 0 && self.destinationLatLong.count > 0) {
                [self callGetNearBySubwayStations];
            }
        }];
}

- (void)callGetNearBySubwayStations
{
    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=%@,%@&rankby=distance&types=subway_station&sensor=true&key=%@", [self.sourceLatLong objectAtIndex:0], [self.sourceLatLong objectAtIndex:1], kGOOGLE_API_KEY];
    
        [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
            NSLog(@"Response %@", responseObject);
            /*
            NSString *strLat = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
            
            [self.sourceLatLong addObject:strLat];
            
            NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
            [self.sourceLatLong addObject:strLng];
             */
            
            //self.mapView.showsUserLocation = YES;
            
        }];
}

                    
@end
