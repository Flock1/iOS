//
//  TravelRouteVC.m
//  Flock
//
//  Created by Gaurav on 01/11/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "TravelRouteVC.h"
#import "ApiOperation.h"
#import "TravelRouteCell.h"

@interface TravelRouteVC ()<UITableViewDataSource, UITableViewDelegate>

{
    ApiOperation *apiOperation;
}

@property (strong, nonatomic) IBOutlet UITableView *tblRoute;

@property (strong, nonatomic) NSMutableArray *arrTimeInfo;
@property (strong, nonatomic) NSMutableArray *arrRouteDetails;

@end

@implementation TravelRouteVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"In Progress";
    
    self.arrTimeInfo     = [NSMutableArray new];
    self.arrRouteDetails = [NSMutableArray new];
    
    if (self.arrSourceCoordinates.count > 0 && self.arrDestinationCoordinates.count > 0) {
        [self callRouteDetailsService];

    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table Delegates
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrTimeInfo.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    TravelRouteCell *cell = [self.tblRoute dequeueReusableCellWithIdentifier:NSStringFromClass([TravelRouteCell class]) forIndexPath:indexPath];
    cell.lblTime.text = self.arrTimeInfo[indexPath.row];
    return cell;
}

#pragma mark - Service methods

- (void)callRouteDetailsService
{
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%@,%@&destination=%@,%@&sensor=false&mode=transit", [self.arrSourceCoordinates objectAtIndex:0],[self.arrSourceCoordinates objectAtIndex:1], [self.arrDestinationCoordinates objectAtIndex:0], [self.arrDestinationCoordinates objectAtIndex:1]];
    
    [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
        NSLog(@"Response %@", responseObject);
        
        NSArray *tempArray = [[[[responseObject objectForKey:@"routes"] valueForKey:@"legs"] valueForKey:@"steps"] valueForKey:@"steps"];
        
        for (int i =0; i<tempArray.count; i++) {
            NSArray *timeArray = [tempArray objectAtIndex:i];
            for (int j =0; j<timeArray.count; j++) {
                NSString *time = [[[[[timeArray objectAtIndex:0] objectAtIndex:0] valueForKey:@"duration"] objectAtIndex:0] valueForKey:@"text"];

                if (time != [NSNull class]) {
                    [self.arrTimeInfo addObject:time];
                }
            }
        }
        
        NSLog(@"%@", self.arrTimeInfo);
        
        /*
         NSString *strLat = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
         
         [self.sourceLatLong addObject:strLat];
         
         NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
         [self.sourceLatLong addObject:strLng];
         */
        
        //self.mapView.showsUserLocation = YES;
        
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
