//
//  ApiOperation.m
//  Flock
//
//  Created by Gaurav on 17/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "ApiOperation.h"

static ApiOperation *operationManager = nil;

@interface ApiOperation ()

//- (void)CompletionHandler:(void (^)(id, NSError*))handler;

@end


@implementation ApiOperation

+ (ApiOperation *)operationManager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        operationManager = [self new];
    });
    return operationManager;
}

- (void)initWithUrlSession:(NSString *)strUrl withParams:(NSDictionary*)params andCompletion: (void(^)(id responseObject, NSError* error))completionBlock
{
    NSURLRequest *request = [NSURLRequest requestWithURL:
                             [NSURL URLWithString:strUrl]];
    
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data,
                                               NSError *connectionError) {
                               // handle response
                               completionBlock(response, connectionError);
                           }];
}

@end
