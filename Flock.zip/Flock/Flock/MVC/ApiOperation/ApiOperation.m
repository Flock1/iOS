//
//  ApiOperation.m
//  Flock
//
//  Created by Gaurav on 17/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "ApiOperation.h"

static ApiOperation *operationManager = nil;

@interface ApiOperation ()

//- (void)CompletionHandler:(void (^)(id, NSError*))handler;

@end


@implementation ApiOperation

+ (NSURLSession *)dataSession {
    static NSURLSession *session = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        // Initialize Session Configuration
        //NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
        

        // Initialize Session Manager

        session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        
    });
    return session;
}

+ (void)initWithUrlSession:(NSString *)strUrl withParams:(NSDictionary*)params andCompletion: (void(^)(id responseObject, NSError* error))completionBlock
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:strUrl]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:60.0];
    NSError *err;
    if (params.count > 0) {
        NSData *postData = [NSJSONSerialization dataWithJSONObject:params options:0 error:&err];
        [request setHTTPBody:postData];
    }
    
    
    
    NSURLSessionDataTask *dataTask =
    [[self dataSession] dataTaskWithRequest:request completionHandler:
     ^(NSData *data, NSURLResponse *response, NSError *error) {
         
         NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
         
         completionBlock(responseDict, error);
     }];
    
    [dataTask resume];
}

@end
