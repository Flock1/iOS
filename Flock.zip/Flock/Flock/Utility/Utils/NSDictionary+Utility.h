//
//  NSDictionary+Utility.h
//  AgPhd
//
//  Created by Gaurav on 17/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Utility)

- (id)objectForKeyNotNull:(id)key;

@end
