

#import "Util.h"
#import <sys/utsname.h>

@interface Util()

@end

@implementation Util


#pragma mark - Image and Color

+ (BOOL)isiOS8
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8)
        return YES;
    else
        return NO;
}

+ (BOOL)isiOS7
{
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1)
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

+ (BOOL)iPhone6PlusDevice{
    if ([UIScreen mainScreen].scale > 2.9) return YES;   // Scale is only 3 when not in scaled mode for iPhone 6 Plus
    return NO;
}

+ (BOOL) iPhone6PlusUnZoomed
{
    if ([self iPhone6PlusDevice]){
        if ([UIScreen mainScreen].bounds.size.height > 720.0) return YES;  // Height is 736, but 667 when zoomed.
    }
    return NO;
}

+ (NSString *)machineName
{
    struct utsname systemInfo;
    uname(&systemInfo);
    
    return [NSString stringWithCString:systemInfo.machine
                              encoding:NSUTF8StringEncoding];
}


+ (BOOL)boolFromValue:(id)value
{
    if ([value isKindOfClass:[NSString class]])
    {
        NSString *strValue      = (NSString *)value;
        if ([strValue isEqualToString:@"1"])
        {
            return TRUE;
        }
        else
            if ([strValue isEqualToString:@"0"])
            {
                return FALSE;
            }
    }
    
    return FALSE;
}


+ (NSArray *)getSortedArrayFromSet:(NSSet *)set withKey:(NSString *)strKey ascending:(BOOL)ascending
{
    NSArray *sortDescriptors    = [NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:strKey ascending:ascending]];
    NSArray *arrSorted          = [[set allObjects] sortedArrayUsingDescriptors:sortDescriptors];
    
    return arrSorted;
}

+ (BOOL)removeFileAtPath:(NSString *)strFilePath
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    return [fileManager removeItemAtPath:strFilePath error:nil];
}

+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
    assert([[NSFileManager defaultManager] fileExistsAtPath:[URL path]]);
    
    NSError *error = nil;
    BOOL success = [URL setResourceValue:[NSNumber numberWithBool: YES]
                                  forKey:NSURLIsExcludedFromBackupKey
                                   error:&error];
    if(!success)
    {
        NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
    }
    else
    {
        NSLog(@"success in excluding %@ from backup", [URL lastPathComponent]);
    }
    
    return success;
}

+ (id)getStringFromObject:(id)object
{
    if ([object isKindOfClass:[NSString class]])
    {
        return object;
    }
    else
    {
        return [NSString stringWithFormat:@"%@", object];
    }
}

+ (id)getNumberFromObject:(id)object
{
    if ([object isKindOfClass:[NSNumber class]])
    {
        return object;
    }
    else
    {
        return [NSNumber numberWithInt:[object intValue]];
    }
}

+ (NSString *)getStringFromGMTDate:(NSDate *)date withFormat:(NSString *)strFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:strFormat];
    
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormat setTimeZone:gmt];
    
    NSString *strDate = [dateFormat stringFromDate:date];
    
    return strDate;
}

+ (NSString *)getStringFromDate:(NSDate *)date withFormat:(NSString *)strFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:strFormat];
    
    NSString *strDate = [dateFormat stringFromDate:date];
    
    return strDate;
}

+ (NSDate *)getDateFromString:(NSString *)strDate withFormat:(NSString *)strFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:strFormat];

    
    NSDate *date = [dateFormat dateFromString:strDate];
    
    return date;
}

+ (NSMutableArray *)addUniqueObjectsFromArray:(NSArray *)arrSource intoArray:(NSMutableArray *)arrDestination
{
    for (id obj in arrSource)
    {
        if (![arrDestination containsObject:obj])
        {
            [arrDestination addObject:obj];
        }
    }
    
    return arrDestination;
}

+ (NSMutableArray *)excludeDuplicateObjectsFromArray:(NSArray *)arrSource containedInArray:(NSArray *)arrDestination
{
    NSMutableArray *arrFinal = [NSMutableArray arrayWithArray:nil];
    
    for (id obj in arrSource)
    {
        if (![arrDestination containsObject:obj])
        {
            [arrFinal addObject:obj];
        }
    }
    
    return arrFinal;
}



#pragma mark - Alert Methods

+ (void)showAlertWithTitle:(NSString *)title
{
    [self showAlertWithTitle:title message:@""];

}

// Show Network alert message
+ (void)showNetWorkAlert
{
    [self showAlertWithTitle:@"No Network Connection" message:@"Please check your connection and try again."];
    
}

+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message
{
    [[[UIAlertView alloc] initWithTitle:title
                                message:message
                               delegate:nil
                      cancelButtonTitle:@"OK"
                      otherButtonTitles:nil] show];
}

/**
 **     Remove starting words characters from string
 **/

+ (NSString *)substringFromString:(NSString *)input andWordsCount:(NSInteger )wordsCount{
    __block NSUInteger index = NSNotFound;
    __block NSUInteger count = 0;
    [input enumerateSubstringsInRange:NSMakeRange(0, [input length]) options:(NSStringEnumerationByWords|NSStringEnumerationSubstringNotRequired) usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
        
        if (++count == wordsCount) {
            index = substringRange.location;
            *stop = YES;
        }
    }];
    if (index == NSNotFound) {
        return @"";
    } else {
        return [input substringFromIndex:index];
    }
}

/**
 **     Remove all leading and new line characters from string
 **/
+ (NSString*)stringByTrimmingLeadingWhitespace:(NSString *)string {
    NSInteger i = 0;
    
    while ((i < [string length])
           && [[NSCharacterSet whitespaceAndNewlineCharacterSet] characterIsMember:[string characterAtIndex:i]]) {
        i++;
    }
    return [string substringFromIndex:i];
}

+ (NSString*)stringByTrimmingTralingWhitespace:(NSString *)string
{
    NSInteger i = string.length;
    
    while ((i > [string length])
           && [[NSCharacterSet whitespaceAndNewlineCharacterSet] characterIsMember:[string characterAtIndex:i]]) {
        i--;
    }
    return [string substringFromIndex:i];
}

+ (NSString*)getValidString:(NSString *)string
{
    if (string == nil)
        return @"";
    
    if ([string isKindOfClass:[NSNull class]] || [string isEqualToString:@"<null>"] || [string isEqualToString:@"(null)"])
    {
        string = @"";
        return string;
    }
    
    if (string.length > 0)
        string = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    else
        string = @"";
    
    return string;
}

+ (NSString*)removeWhiteSpace:(NSString*)string
{
    NSString *search;
    if (string.length > 0)
    {
        search = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    }
    
    if ([string isKindOfClass:[NSNull class]]|| [string isEqualToString:@"<null>"])
    {
        search = @"";
    }
    if ([string isEqualToString:@""]) {
        search = @"";
    }
    return search;
}

#pragma mark - Base64 conversion for image

+ (NSString*)base64forData:(NSData*)theData {
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}

@end