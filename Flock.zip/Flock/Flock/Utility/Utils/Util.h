#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Util : NSObject 
{
	
}
+ (BOOL)isiOS8;
+ (BOOL)isiOS7;
+ (BOOL)iPhone6PlusDevice;
+ (BOOL)iPhone6PlusUnZoomed;
+ (NSString *)machineName;


/**
 **     Get BOOL from an id value
 **/
+ (BOOL)boolFromValue:(id)value;

/**
 **     Check string if it's a valid email
 **/
+ (NSArray *)getSortedArrayFromSet:(NSSet *)set withKey:(NSString *)strKey ascending:(BOOL)ascending;

+ (BOOL)removeFileAtPath:(NSString *)strFilePath;

+ (id)getStringFromObject:(id)object;
+ (id)getNumberFromObject:(id)object;
+ (NSString *)getStringFromGMTDate:(NSDate *)date withFormat:(NSString *)strFormat;
+ (NSString *)getStringFromDate:(NSDate *)date withFormat:(NSString *)strFormat;
+ (NSDate *)getDateFromString:(NSString *)strDate withFormat:(NSString *)strFormat;
+ (NSMutableArray *)addUniqueObjectsFromArray:(NSArray *)arrSource intoArray:(NSMutableArray *)arrDestination;
+ (NSMutableArray *)excludeDuplicateObjectsFromArray:(NSArray *)arrSource containedInArray:(NSArray *)arrDestination;

/**
 **     Methods for displaying AlertView with OK title on cancle button
 **/
+ (void)showNetWorkAlert;
+ (void)showAlertWithTitle:(NSString *)title;
+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message;

/**
 **     Remove desired words from starting of string
 **/
+ (NSString *)substringFromString:(NSString *)input andWordsCount:(NSInteger )wordsCount;

+ (NSString*)stringByTrimmingLeadingWhitespace:(NSString *)string;

+ (NSString*)stringByTrimmingTralingWhitespace:(NSString *)string;

+ (NSString*)getValidString:(NSString *)string;

+ (NSString*)removeWhiteSpace:(NSString*)string;


/**
 **     Base 64 conversion method
 **/

+ (NSString*)base64forData:(NSData*)theData;


@end