//
//  NSDictionary+Utility.m
//  Flock
//
//  Created by Gaurav on 17/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "NSDictionary+Utility.h"

@implementation NSDictionary (Utility)

// in case of [NSNull null] values a nil is returned ...
- (id)objectForKeyNotNull:(id)key
{
    id object = [self objectForKey:key];
    if (object == [NSNull null])
        return nil;
    
    return object;
}

@end
