//
//  Constants.h
//  Flock
//
//  Created by Gaurav on 19/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#ifndef Flock_Constants_h
#define Flock_Constants_h

#define kGOOGLE_API_KEY @"AIzaSyB1ydbmZhmslBzFSAiOT6V168vMLwcTnvw"

//************ Enums Define Here **************//
typedef NS_ENUM(NSUInteger, task) {
    kTaskNearBySubways
};

#endif
