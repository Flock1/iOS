//
//  TravelRouteCell.m
//  Flock
//
//  Created by Gaurav on 01/11/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "TravelRouteCell.h"

@implementation TravelRouteCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
