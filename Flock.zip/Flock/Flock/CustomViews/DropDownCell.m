//
//  DropDownCell.m
//  Flock
//
//  Created by Gaurav on 27/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "DropDownCell.h"

@implementation DropDownCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
