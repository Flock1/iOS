//
//  TravelRouteCell.h
//  Flock
//
//  Created by Gaurav on 01/11/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TravelRouteCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblTime;
@property (nonatomic, strong) IBOutlet UILabel *lblRouteDetail;

@end
