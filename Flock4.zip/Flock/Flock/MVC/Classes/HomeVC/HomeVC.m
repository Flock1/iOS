//
//  HomeVC.m
//  Flock
//
//  Created by Gaurav on 19/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "HomeVC.h"
#import "ApiOperation.h"
#import "Constants.h"
#import "DropDownCell.h"
#import "TravelRouteVC.h"
#import <GoogleMaps/GoogleMaps.h>

@interface HomeVC ()<UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate>

{
    NSArray *arrGeometry;
    NSMutableArray *arrPlaceName;
    NSMutableArray *arrPhotoUrl;
    
    //CLLocationManager *locationManager;
    NSString *currentLatitude;
    NSString *currentLongitude;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    GMSPlacesClient *_placesClient;
    ApiOperation *apiOperation;
    
}

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (strong, nonatomic) IBOutlet UITextField *tfSource;
@property (strong, nonatomic) IBOutlet UITextField *tfDestination;

@property (strong, nonatomic) IBOutlet UIButton *btnShowRoute;

@property (strong, nonatomic) IBOutlet UIView      *dropDownView;
@property (strong, nonatomic) IBOutlet  UITableView *tblDropDown;

@property (strong, nonatomic) NSArray *arrSource;
@property (strong, nonatomic) NSArray *arrDestination;

@property (strong, nonatomic) NSArray *arrSourceReference;
@property (strong, nonatomic) NSArray *arrDestinationReference;

@property (strong, nonatomic) NSString *strSelectedSourceReference;
@property (strong, nonatomic) NSString *strSelectedDestinReference;

@property (strong, nonatomic) NSMutableArray *sourceLatLong;
@property (strong, nonatomic) NSMutableArray *destinationLatLong;

@property (strong, nonatomic) NSMutableArray *arrSubwayResults;
@property (strong, nonatomic) NSMutableArray *arrSubwayDestinResults;



@property (nonatomic)  BOOL isSourceTable;

@property (nonatomic, weak) IBOutlet NSLayoutConstraint *topConstraintDropDownView;

- (IBAction)btnDestination_Action:(id)sender;
- (IBAction)btnSource_Action:(id)sender;

@end

@implementation HomeVC

#pragma mark - View LifeCycle
- (void)placeAutocomplete:(NSString *)searchText {
    
    //GMSVisibleRegion visibleRegion = self.mapView.projection.visibleRegion;
    
    CLLocationCoordinate2D location = CLLocationCoordinate2DMake(40.719578,-73.877027);
    GMSCoordinateBounds *bounds = [[GMSCoordinateBounds alloc] initWithCoordinate:location
                                                                       coordinate:location];
    GMSAutocompleteFilter *filter = [[GMSAutocompleteFilter alloc] init];
    filter.type = kGMSPlacesAutocompleteTypeFilterGeocode;
    
    [_placesClient autocompleteQuery:@"nyu"
                              bounds:bounds
                              filter:filter
                            callback:^(NSArray *results, NSError *error) {
                                if (error != nil) {
                                    NSLog(@"Autocomplete error %@", [error localizedDescription]);
                                    return;
                                }
                                
                                NSMutableArray *tempArrayForPlacesName = [NSMutableArray new];
                                NSMutableArray *tempArrayRef           = [NSMutableArray new];
                                
                                for (GMSAutocompletePrediction* result in results) {
                                    NSLog(@"Result '%@' with placeID %@", result.attributedFullText.string, result.placeID);
                                    
                                    
                                        [tempArrayForPlacesName addObject:result.attributedFullText.string];
                                        [tempArrayRef addObject:result.placeID];
                                    
                                        [tempArrayForPlacesName addObject:result.attributedFullText.string];
                                        [tempArrayRef addObject:result.placeID];
                                        
                                    
                                }
                                self.arrSource          = nil;
                                self.arrSourceReference = nil;
                                self.arrDestination     = nil;
                                self.arrDestinationReference = nil;
                                
                                if (self.isSourceTable) {
                                    self.arrSource          = [NSArray arrayWithArray:tempArrayForPlacesName];
                                    self.arrSourceReference = [NSArray arrayWithArray:tempArrayRef];
                                }else
                                {
                                    self.arrDestination          = [NSArray arrayWithArray:tempArrayForPlacesName];
                                    self.arrDestinationReference = [NSArray arrayWithArray:tempArrayRef];
                                }
     
                                // Update view
                                dispatch_async(dispatch_get_main_queue(), ^{
                                   
                                    self.dropDownView.hidden = NO;
                                    
                                    [self.tblDropDown reloadData];
                                });
                                
                               
                            }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.arrSource               = [NSArray new];
    self.arrDestination          = [NSArray new];
    self.arrSubwayResults        = [NSMutableArray new];
    self.arrSubwayDestinResults  = [NSMutableArray new];
    
    self.arrSourceReference      = [NSArray new];
    self.arrDestinationReference = [NSArray  new];
    
    self.sourceLatLong           = [NSMutableArray new];
    self.destinationLatLong      = [NSMutableArray new];
    
    self.tfSource.userInteractionEnabled      = YES;
    self.tfDestination.userInteractionEnabled = YES;
    self.btnShowRoute.userInteractionEnabled  = NO;
    
    _placesClient = [GMSPlacesClient new];
    
    

    
    self.dropDownView.hidden = YES;
    
    self.dropDownView.layer.borderWidth   = 2.0f;
    self.dropDownView.layer.borderColor   = [UIColor grayColor].CGColor;
    
    self.dropDownView.layer.masksToBounds = YES;
    
    [self CurrentLocationIdentifier];
    
    //For Testing only
    /*
    CLLocationCoordinate2D currentLoc = CLLocationCoordinate2DMake(22.719568,75.857727 );
    //[self.mapView setus]
    [self.mapView setCenterCoordinate:currentLoc];
     */
    
    }


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"TravelRouteVC"]) {
       
        TravelRouteVC *routeVC            = [segue destinationViewController];
        NSLog(@"subwya source %@", self.arrSubwayResults);
        NSLog(@"subway source %@", self.arrSubwayDestinResults);
        
        routeVC.arrDestinationCoordinates = self.destinationLatLong;
        routeVC.arrSourceCoordinates      = self.sourceLatLong;
        routeVC.arrSubwaysList            = [self.arrSubwayResults subarrayWithRange:NSMakeRange(0, 3)];
        routeVC.arrSubwaysDestinList      = [self.arrSubwayDestinResults subarrayWithRange:NSMakeRange(0, 3)];
    }
}
 

#pragma mark - Location Methods
//------------ Current Location Address-----
-(void)CurrentLocationIdentifier
{
    locationManager = [CLLocationManager new];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [locationManager requestWhenInUseAuthorization];
        [locationManager requestAlwaysAuthorization];
    }
    //---- For getting current gps location
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
    //------
    
    self.mapView.showsUserLocation = YES;
    
    /*
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorized ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
     
    }*/
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    currentLocation = [locations lastObject];
    [locationManager stopUpdatingLocation];
    
    if (currentLocation != nil) {
        
        currentLongitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        currentLatitude  = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        
        self.tfSource.text = [NSString stringWithFormat:@"My Location. Click to change"];
        self.btnShowRoute.hidden = NO;
        self.btnShowRoute.userInteractionEnabled = NO;
        //[self callGoogleAutoCompleteService];
    }
}

#pragma mark - Action Methods
- (IBAction)btnSource_Action:(id)sender
{
    self.arrSource = nil;
    self.arrSourceReference = nil;
    [self.tblDropDown reloadData];

    
    if ([self.tfDestination isFirstResponder]) {
        [self.tfDestination resignFirstResponder];
    }
    
    self.isSourceTable = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        self.dropDownView.hidden = NO;
        self.topConstraintDropDownView.constant = 132.0f;
        [self.view layoutSubviews];
    });
    
    self.btnShowRoute.hidden = YES;

    [self.tfSource becomeFirstResponder];
}

- (IBAction)btnDestination_Action:(id)sender;
{
    self.arrDestination = nil;
    self.arrDestinationReference = nil;
    
    if ([self.tfSource isFirstResponder]) {
        [self.tfSource resignFirstResponder];
    }
    
    self.isSourceTable = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tblDropDown reloadData];
        self.dropDownView.hidden = NO;
        self.topConstraintDropDownView.constant = 178.0f;
        [self.view layoutSubviews];

    });
    
    [self.tfDestination becomeFirstResponder];
}

- (IBAction)btnFlockNavigation_Action:(id)sender;
{
    
    
     //[self performSegueWithIdentifier:@"TravelRouteVC" sender:self];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self performSegueWithIdentifier:@"TravelRouteVC" sender:self];
    });
}

#pragma mark - Tableview Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isSourceTable) {
        return self.arrSource.count;
    }else
        {
            return self.arrDestination.count;
        }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //static NSString *cellIdentifier = @"cell";
    
    DropDownCell *cell = [self.tblDropDown dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    if (self.isSourceTable) {
        cell.textLabel.text = self.arrSource[indexPath.row];
    }else
        {
            cell.textLabel.text = self.arrDestination[indexPath.row];
        }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isSourceTable) {
        self.tfSource.text = self.arrSource[indexPath.row];
        
        self.strSelectedSourceReference = self.arrSourceReference[indexPath.row];
        [self  callGetLatLongfromReference:self.strSelectedSourceReference];

        [self.tfSource resignFirstResponder];
    }
    else
        {
            self.tfDestination.text = self.arrDestination[indexPath.row];
            self.strSelectedDestinReference = self.arrDestinationReference[indexPath.row];
            
            [self  callGetLatLongfromReference:self.strSelectedDestinReference];
            self.btnShowRoute.userInteractionEnabled  = YES;
            [self.btnShowRoute setHidden:NO];
            [self.tfDestination resignFirstResponder];
            //[self callGetNearBySubwayStations];
        }
    
    [self.dropDownView  setHidden:YES];
}

#pragma mark - TextField Delegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([self.tfSource.text isEqualToString:@"My Location. Click to change"])
    {
        self.tfDestination.text = self.tfSource.text = @"";
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    self.btnShowRoute.hidden = NO;
    
    self.btnShowRoute.userInteractionEnabled = YES;
    [textField resignFirstResponder];
    [self.dropDownView setHidden:YES];
    self.btnShowRoute.hidden = NO;

    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string) {
        [self placeAutocomplete: textField.text];
        //[self callGoogleAutoCompleteService: textField.text];
    }
    return YES;
}

#pragma mark - MKMapView delegates

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
    
    static NSString* AnnotationIdentifier = @"Annotation";
    MKPinAnnotationView *pinView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotationIdentifier];
    
    if (!pinView) {
        
        MKPinAnnotationView *customPinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotationIdentifier];
        if (annotation == mapView.userLocation){
            
            NSLog(@"Coordinate %f,=== %f", mapView.userLocation.coordinate.latitude, mapView.userLocation.coordinate.longitude);
            customPinView.image = [UIImage imageNamed:@"marker40"];
        }
        else{
            customPinView.image = [UIImage imageNamed:@"marker20"];
        }
        customPinView.animatesDrop = NO;
        customPinView.canShowCallout = YES;
        return customPinView;
        
    } else {
        
        pinView.annotation = annotation;
    }
    
    return pinView;
}

#pragma mark - service Methods

- (void)callGoogleAutoCompleteService:(NSString *)searchText
{
    NSString *types     = [NSString new];
    //types = @"establishment|subway_station";
    
    types = @"establishment";

    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&location=40.719578,-73.877027&radius=5000&components=country:us&key=%@", searchText, kGOOGLE_API_KEY];
    
    //NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/json?input=%@&location=%@,%@&radius=5000&sensor=false&types=%@&key=%@", searchText, currentLatitude, currentLongitude, types, kGOOGLE_API_KEY];
    
    //if ((currentLatitude.length > 0) && (currentLongitude.length > 0)) {
        
    [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
        NSLog(@"Response %@", responseObject);
        
        // Update view
        dispatch_async(dispatch_get_main_queue(), ^{
            if (self.isSourceTable) {
                self.arrSource = [[responseObject objectForKey:@"predictions"] valueForKey:@"description"];
                
                self.arrSourceReference = [[responseObject objectForKey:@"predictions"] valueForKey:@"reference"];
            }else
            {
                self.arrDestination = [[responseObject objectForKey:@"predictions"] valueForKey:@"description"];
                self.arrDestinationReference = [[responseObject objectForKey:@"predictions"] valueForKey:@"reference"];

            }
            self.dropDownView.hidden = NO;
            
            [self.tblDropDown reloadData];
        });
        
    }];
    //}
}

- (void)callGetLatLongfromReference:(NSString *)reference
{
    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/details/json?placeid=%@&sensor=false&key=%@", reference, kGOOGLE_API_KEY];
    
        [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
            NSLog(@"Response %@", responseObject);
            
            NSString *strLat = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
            
            if (self.isSourceTable) {
                [self.sourceLatLong removeAllObjects];
                
                [self.sourceLatLong addObject:strLat];
                
                NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
                [self.sourceLatLong addObject:strLng];
                
                [self callGetNearBySubwayStations:[self.sourceLatLong objectAtIndex:0] AndLongitude:[self.sourceLatLong objectAtIndex:1]];
                
            }else
                {
                    [self.destinationLatLong removeAllObjects];
                    
                    [self.destinationLatLong addObject:strLat];
                    
                    NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
                    [self.destinationLatLong addObject:strLng];
                    
                    [self callGetNearBySubwayStations:[self.destinationLatLong objectAtIndex:0] AndLongitude:[self.destinationLatLong objectAtIndex:1]];
                }
        }];
}

- (void)callGetNearBySubwayStations:(NSString *)latitude AndLongitude:(NSString *)longitude
{
    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=%@,%@&rankby=distance&types=subway_station&sensor=true&key=%@", latitude, longitude, kGOOGLE_API_KEY];
    
        [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
            NSLog(@"Response %@", responseObject);
            
            NSArray *tempSubwayArray = [responseObject objectForKey:@"results"];
            NSLog(@"%@",tempSubwayArray);
            
            // Store all data without duplicate station name
           
            NSMutableArray *arrName = [NSMutableArray new];

            [tempSubwayArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
               
                NSString *name = [obj valueForKey:@"name"];
                
                if ([arrName containsObject:name]) {
                    NSLog(@"Duplicate object found // Object name === %@",name);
                }
                else
                {
                    [arrName addObject:name];
                    
                    if (self.isSourceTable) {
                        [self.arrSubwayResults addObject:obj];
                    }else
                    {
                       [self.arrSubwayDestinResults addObject:obj];
                    }
                }
            }];
        }];
}

                    
@end
