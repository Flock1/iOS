//
//  TravelRouteVC.h
//  Flock
//
//  Created by Gaurav on 01/11/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TravelRouteVC : UIViewController

@property (nonatomic, strong) NSArray *arrSourceCoordinates;
@property (nonatomic, strong) NSArray *arrDestinationCoordinates;
@property (nonatomic, strong) NSArray *arrSubwaysList;
@property (nonatomic, strong) NSArray *arrSubwaysDestinList;

@end
