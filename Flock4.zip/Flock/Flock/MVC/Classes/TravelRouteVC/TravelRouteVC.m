//
//  TravelRouteVC.m
//  Flock
//
//  Created by Gaurav on 01/11/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "TravelRouteVC.h"
#import "ApiOperation.h"
#import "TravelRouteCell.h"
#import "NSString+HTML.h"

@interface TravelRouteVC ()<UITableViewDataSource, UITableViewDelegate>

{
    ApiOperation *apiOperation;
}

@property (strong, nonatomic) IBOutlet UITableView *tblRoute;

@property (strong, nonatomic) NSMutableArray *arrTimeInfo;
@property (strong, nonatomic) NSMutableArray *arrRouteDetails;

@end

@implementation TravelRouteVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"In Progress";
    
    NSLog(@"Subways %@",[self.arrSubwaysList objectAtIndex:0]);
    
    self.arrTimeInfo     = [NSMutableArray new];
    self.arrRouteDetails = [NSMutableArray new];
    
    NSMutableArray *arrSourceCoordinates = [NSMutableArray new];
    NSMutableArray *arrDestinCoordinates = [NSMutableArray new];
    
    for (id obj in self.arrSubwaysList) {
        [arrSourceCoordinates removeAllObjects];
        [arrSourceCoordinates addObject:[[[obj objectForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"]];
        [arrSourceCoordinates addObject:[[[obj objectForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"]];
    }
    
    for (id obj in self.arrSubwaysDestinList) {
        [arrDestinCoordinates removeAllObjects];
        
        [arrDestinCoordinates addObject:[[[obj objectForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"]];
        [arrDestinCoordinates addObject:[[[obj objectForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"]];
    }

    [self callRouteDetailsService:arrSourceCoordinates andDestination:arrDestinCoordinates];
    
    if (self.arrSourceCoordinates.count > 0 && self.arrDestinationCoordinates.count > 0) {
       // [self callRouteDetailsService];
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table Delegates
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrTimeInfo.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TravelRouteCell *cell = [self.tblRoute dequeueReusableCellWithIdentifier:NSStringFromClass([TravelRouteCell class]) forIndexPath:indexPath];
    cell.lblTime.text = self.arrTimeInfo[indexPath.row];
    //cell.lblRouteDetail.text = self.arrRouteDetails[indexPath.row];
    return cell;
}

#pragma mark - Service methods

- (void)callRouteDetailsService:(NSArray *)sourceLatLong andDestination:(NSArray *)destinLatLong
{
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%@,%@&destination=%@,%@&sensor=false&mode=transit", [sourceLatLong objectAtIndex:0],[sourceLatLong objectAtIndex:1], [destinLatLong objectAtIndex:0], [destinLatLong objectAtIndex:1]];
    
    [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
        NSLog(@"Response %@", responseObject);
        
        NSArray *tempArray = [[[[responseObject objectForKey:@"routes"] valueForKey:@"legs"] valueForKey:@"steps"] valueForKey:@"steps"];
        
        NSArray *arrShortName = [[[[[[responseObject objectForKey:@"routes"] valueForKey:@"legs"] valueForKey:@"steps"] valueForKey:@"transit_details"] valueForKey:@"line"] valueForKey:@"short_name"];
        
        NSString *shortName = [[[arrShortName objectAtIndex:0] objectAtIndex:0] componentsJoinedByString:@","];
        NSMutableString *mutableShortName;
        [mutableShortName setString:shortName];
        [mutableShortName replaceOccurrencesOfString:@"<null>" withString:@"" options:0 range:NSMakeRange(0, [@"<null>" length])];
        [mutableShortName replaceOccurrencesOfString:@"," withString:@"" options:0 range:NSMakeRange(0, [@"," length])];
        
        
        
        
        /*
        for (int i =0; i<tempArray.count; i++) {
            NSArray *timeArray = [[tempArray objectAtIndex:i] objectAtIndex:0] ;
            for (int j =0; j<timeArray.count; j++) {
                NSArray *arr = [timeArray objectAtIndex:j];
                if ( ![arr isKindOfClass:[NSNull class]] && arr.count > 0 ) {
                    
                    for (id object in arr) {
                        NSString *time  = [[object valueForKey:@"duration"] valueForKey:@"text"];
                        NSString *route = [object valueForKey:@"html_instructions"];
                        
                        if (time != [NSNull class] && time.length > 0) {
                            
                            [self.arrTimeInfo addObject:time];
                            //[self.arrRouteDetails addObject:]
                        }
                        
                        if (route != [NSNull class] && route.length > 0) {
                            
                            [self.arrRouteDetails addObject:[[[route stringByStrippingTags] stringByRemovingNewLinesAndWhitespace] stringByDecodingHTMLEntities]
                             ];
                        }
                    }
                }
            }
        }
        */
        
        NSLog(@"%@ \n Route%@", self.arrTimeInfo, self.arrRouteDetails);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tblRoute reloadData];

        });
        
        /*
         NSString *strLat = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"];
         
         [self.sourceLatLong addObject:strLat];
         
         NSString *strLng = [[[[responseObject objectForKey:@"result"] valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"];
         [self.sourceLatLong addObject:strLng];
         */
        
        //self.mapView.showsUserLocation = YES;
        
    }];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
