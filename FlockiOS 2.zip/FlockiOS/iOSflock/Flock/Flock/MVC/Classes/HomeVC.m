//
//  HomeVC.m
//  Flock
//
//  Created by Gaurav on 19/10/15.
//  Copyright (c) 2015 Gaurav. All rights reserved.
//

#import "HomeVC.h"
#import "ApiOperation.h"
#import "Constants.h"
#import "DropDownCell.h"
#import <GoogleMaps/GoogleMaps.h>

@interface HomeVC ()<UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate>

{
    NSArray *arrGeometry;
    NSMutableArray *arrPlaceName;
    NSMutableArray *arrPhotoUrl;
    
    //CLLocationManager *locationManager;
    NSString *currentLatitude;
    NSString *currentLongitude;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    
     ApiOperation *apiOperation;
    
}

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (strong, nonatomic) IBOutlet UITextField *tfSource;
@property (strong, nonatomic) IBOutlet UITextField *tfDestination;

@property (strong, nonatomic) IBOutlet UIView      *dropDownView;
@property (strong, nonatomic) IBOutlet  UITableView *tblDropDown;

@property (strong, nonatomic) NSArray *arrSource;
@property (strong, nonatomic) NSArray *arrDestination;

@property (nonatomic)  BOOL isSourceTable;

- (IBAction)btnDestination_Action:(id)sender;
- (IBAction)btnSource_Action:(id)sender;

@end

@implementation HomeVC

- (void)placeAutocomplete:(NSString *)searchText {
    
    GMSPlacesClient *placesClient = [GMSPlacesClient new];
    GMSAutocompleteFilter *filter = [[GMSAutocompleteFilter alloc] init];
    filter.type = kGMSPlacesAutocompleteTypeFilterEstablishment;
    
    [placesClient autocompleteQuery:searchText
                              bounds:nil
                              filter:filter
                            callback:^(NSArray *results, NSError *error) {
                                if (error != nil) {
                                    NSLog(@"Autocomplete error %@", [error localizedDescription]);
                                    return;
                                }
                                
                                for (GMSAutocompletePrediction* result in results) {
                                    NSLog(@"Result '%@' with placeID %@", result.attributedFullText.string, result.placeID);
                                }
                            }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.arrSource      = [NSArray new];
    self.arrDestination = [NSArray new];
    
    self.tfSource.userInteractionEnabled = YES;
    
    self.dropDownView.hidden = YES;
    
    //self.dropDownView.layer.cornerRadius = 2.0f;
    self.dropDownView.layer.borderWidth  = 2.0f;
    self.dropDownView.layer.borderColor  = [UIColor grayColor].CGColor;
    
    self.dropDownView.layer.masksToBounds = YES;
    
    [self CurrentLocationIdentifier];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma MAR - Location Methods
//------------ Current Location Address-----
-(void)CurrentLocationIdentifier
{
    locationManager = [CLLocationManager new];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [locationManager requestWhenInUseAuthorization];
        [locationManager requestAlwaysAuthorization];
    }
    //---- For getting current gps location
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
    //------
    
    self.mapView.showsUserLocation = YES;
    /*
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorized ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
     
    }*/
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    currentLocation = [locations lastObject];
    [locationManager stopUpdatingLocation];
    
    if (currentLocation != nil) {
        
        currentLongitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        currentLatitude  = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        
        self.tfSource.text = [NSString stringWithFormat:@"My Location. Click to change"];
        
        //[self callGoogleAutoCompleteService];
    }
}

#pragma mark - Action Methods
- (IBAction)btnSource_Action:(id)sender
{
    if ([self.tfDestination isFirstResponder]) {
        [self.tfDestination resignFirstResponder];
    }
    
    self.isSourceTable = YES;
    self.dropDownView.hidden = NO;
    [self.tfSource becomeFirstResponder];
}

- (IBAction)btnDestination_Action:(id)sender;
{
    if ([self.tfSource isFirstResponder]) {
        [self.tfSource resignFirstResponder];
    }
    
    self.isSourceTable = YES;
    [self.tfDestination becomeFirstResponder];
    
}

#pragma mark - Tableview Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isSourceTable) {
        return self.arrSource.count;
    }else
        {
            return self.arrDestination.count;
        }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //static NSString *cellIdentifier = @"cell";
    
    DropDownCell *cell = [self.tblDropDown dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    if (self.isSourceTable) {
        cell.textLabel.text = self.arrSource[indexPath.row];
    }else
        {
            cell.textLabel.text = self.arrDestination[indexPath.row];
        }
    
    return cell;
}

#pragma mar - TextField Delegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    self.tfDestination.text = self.tfSource.text = @"";
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self.dropDownView setHidden:YES];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string) {
        //[self callGoogleAutoCompleteService:string];
        
        [self placeAutocomplete:string];
    }
    return YES;
}

#pragma mark - service Methods

- (void)callGoogleAutoCompleteService:(NSString *)searchText
{
    NSString *types     = [NSString new];
    //types = @"establishment|subway_station";
    
    types = @"establishment";

    
    NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&location=%@,%@&radius=5000&types=%@&key=%@", searchText, currentLatitude, currentLongitude, types, kGOOGLE_API_KEY];
    
    //NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/json?input=%@&location=%@,%@&radius=5000&sensor=false&types=%@&key=%@", searchText, currentLatitude, currentLongitude, types, kGOOGLE_API_KEY];
    
    if ((currentLatitude.length > 0) && (currentLongitude.length > 0)) {
        
    [ApiOperation initWithUrlSession:strUrl withParams:nil andCompletion:^(id responseObject, NSError *error) {
        NSLog(@"Response %@", responseObject);
        
        // Update view
        dispatch_async(dispatch_get_main_queue(), ^{
            self.arrSource = [[responseObject objectForKey:@"predictions"] valueForKey:@"description"];
            self.isSourceTable = YES;
            self.dropDownView.hidden = NO;
            
            [self.tblDropDown reloadData];
        });
        
    }];
    }
    
}
                    
@end
